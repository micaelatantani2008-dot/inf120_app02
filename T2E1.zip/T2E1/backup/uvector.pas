unit UVector;

{$mode ObjFPC}{$H+}

interface
uses
  SysUtils;
type
  TVector = class
  private
    datos: array of Integer;
    n: Integer;
    procedure QuickSortRec(izq, der: Integer);
  public
    constructor Crear(tam: Integer);
    procedure Cargar;
    function Mostrar: String;
    procedure Adicionar(x: Integer);
    procedure Insertar(pos, x: Integer);
    function Obtener(pos: Integer): Integer;
    function Cantidad: Integer;
    function BusquedaSecuencial(x: Integer): Integer;
    function BusquedaBinaria(x: Integer): Integer;
    procedure Invertir;
    procedure Rotar;
    procedure OrdenarInsercion;
    procedure OrdenarSeleccion;
    procedure OrdenarIntercambio;
    procedure OrdenarBurbuja;
    procedure QuickSort;
    procedure EliminarRep;
    procedure OrdenarFrec;
    function ComoString: String;
  end;

implementation

function TVector.ComoString: String;
var
  i: Integer;
begin
  Result := '';
  i := 0;
  while i < n do
  begin
    Result := Result + IntToStr(datos[i]);
    if i < n - 1 then
      Result := Result + ' ';
    i := i + 1;
  end;
end;

procedure TVector.OrdenarFrec;
var
  i, j, k, frecI, frecJ, aux: Integer;
begin
  i := 0;
  while i < n - 1 do
  begin
    j := i + 1;
    while j < n do
    begin
      frecI := 0;
      frecJ := 0;
      k := 0;
      while k < n do
      begin
        if datos[k] = datos[i] then
          frecI := frecI + 1;
        if datos[k] = datos[j] then
          frecJ := frecJ + 1;
        k := k + 1;
      end;
      if frecJ > frecI then
      begin
        aux := datos[i];
        datos[i] := datos[j];
        datos[j] := aux;
      end;
      j := j + 1;
    end;
    i := i + 1;
  end;
end;

procedure TVector.EliminarRep;
var
  i, j, k: Integer;
begin
  i := 0;
  while i < n do
  begin
    j := i + 1;
    while j < n do
    begin
      if datos[i] = datos[j] then
      begin
        k := j;
        while k < n - 1 do
        begin
          datos[k] := datos[k + 1];
          k := k + 1;
        end;
        n := n - 1;
      end
      else
        j := j + 1;
    end;
    i := i + 1;
  end;
end;

procedure TVector.QuickSortRec(izq, der: Integer);
var
  i, j, p, aux: Integer;
begin
  i := izq;
  j := der;
  p := datos[(izq + der) div 2];
  while i <= j do
  begin
    while datos[i] < p do
      i := i + 1;
    while datos[j] > p do
      j := j - 1;
    if i <= j then
    begin
      aux := datos[i];
      datos[i] := datos[j];
      datos[j] := aux;
      i := i + 1;
      j := j - 1;
    end;
  end;
  if izq < j then
    QuickSortRec(izq, j);
  if i < der then
    QuickSortRec(i, der);
end;


procedure TVector.QuickSort;
begin
  if n > 1 then
    QuickSortRec(0, n - 1);
end;

procedure TVector.OrdenarBurbuja;
var
  i, j, aux: Integer;
begin
  i := 0;
  while i < n - 1 do
  begin
    j := 0;
    while j < n - 1 - i do
    begin
      if datos[j] > datos[j + 1] then
      begin
        aux := datos[j];
        datos[j] := datos[j + 1];
        datos[j + 1] := aux;
      end;
      j := j + 1;
    end;
    i := i + 1;
  end;
end;

procedure TVector.OrdenarSeleccion;
var
  i, j, pos, aux: Integer;
begin
  i := 0;
  while i < n - 1 do
  begin
    pos := i;
    j := i + 1;
    while j < n do
    begin
      if datos[j] < datos[pos] then
        pos := j;
      j := j + 1;
    end;
    aux := datos[i];
    datos[i] := datos[pos];
    datos[pos] := aux;
    i := i + 1;
  end;
end;

procedure TVector.OrdenarIntercambio;
var
  i, j, aux: Integer;
begin
  i := 0;
  while i < n - 1 do
  begin
    j := i + 1;
    while j < n do
    begin
      if datos[i] > datos[j] then
      begin
        aux := datos[i];
        datos[i] := datos[j];
        datos[j] := aux;
      end;
      j := j + 1;
    end;
    i := i + 1;
  end;
end;

function TVector.BusquedaSecuencial(x: Integer): Integer;
var
  i: Integer;
begin
  i := 0;
  while (i < n) and (datos[i] <> x) do
    i := i + 1;
  if i < n then
    Result := i
  else
    Result := -1;
end;


function TVector.BusquedaBinaria(x: Integer): Integer;
var
  izq, der, medio: Integer;
begin
  izq := 0;
  der := n - 1;
  Result := -1;
  while (izq <= der) and (Result = -1) do
  begin
    medio := (izq + der) div 2;
    if datos[medio] = x then
      Result := medio
    else
      if x < datos[medio] then
        der := medio - 1
      else
        izq := medio + 1;
  end;
end;



constructor TVector.Crear(tam: Integer);
begin
  SetLength(datos, tam);
  n := 0;
end;

procedure TVector.Cargar;
begin
  n := 5;
  datos[0] := 10;
  datos[1] := 20;
  datos[2] := 30;
  datos[3] := 40;
  datos[4] := 50;
end;

function TVector.Mostrar: String;
var
  i: Integer;
begin
  Result := '';
  for i := 0 to n - 1 do
  begin
    Result := Result + IntToStr(datos[i]) + ' ';
  end;
end;

procedure TVector.Adicionar(x: Integer);
begin
    if n < Length(datos) then
    begin
      datos[n] := x;
      n := n + 1;
    end;
end;

procedure TVector.Insertar(pos, x: Integer);
var
  i: Integer;
begin
  if (pos >= 0) and (pos <= n) and (n < Length(datos)) then
  begin
    i := n;
    while i > pos do
    begin
      datos[i] := datos[i - 1];
      i := i - 1;
    end;
    datos[pos] := x;
    n := n + 1;
  end;
end;

function TVector.Obtener(pos: Integer): Integer;
begin
  if (pos >= 0) and (pos < n) then
    Result := datos[pos]
  else
    Result := 0;
end;

function TVector.Cantidad: Integer;
begin
   Result := n;
end;

procedure TVector.Invertir;
var
  i, j, aux: Integer;
begin
  i := 0;
  j := n - 1;
  while i < j do
  begin
    aux := datos[i];
    datos[i] := datos[j];
    datos[j] := aux;
    i := i + 1;
    j := j - 1;
  end;
end;

procedure TVector.Rotar;
var
  i, aux: Integer;
begin
  if n > 1 then
  begin
    aux := datos[n - 1];
    i := n - 1;
    while i > 0 do
    begin
      datos[i] := datos[i - 1];
      i := i - 1;
    end;
    datos[0] := aux;
  end;
end;


procedure TVector.OrdenarInsercion;
var
  i, j, aux: Integer;
begin
  i := 1;
  while i < n do
  begin
    aux := datos[i];
    j := i - 1;
    while (j >= 0) and (datos[j] > aux) do
    begin
      datos[j + 1] := datos[j];
      j := j - 1;
    end;
    datos[j + 1] := aux;
    i := i + 1;
  end;
end;


end.

