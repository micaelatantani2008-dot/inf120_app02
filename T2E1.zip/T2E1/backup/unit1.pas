unit Unit1;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, Grids, StdCtrls, UVector;

type

  { TNumero }

  TNumero = class(TForm)
    BtnAdicionar: TButton;
    BtnMostrar: TButton;
    BtnCantidad: TButton;
    BtnInsertar: TButton;
    BtnCargar: TButton;
    BtnObtener: TButton;
    BtnInvertir: TButton;
    BtnRotar: TButton;
    BtnBusquedaSec: TButton;
    BtnBusquedaBin: TButton;
    BtnInsercion: TButton;
    BtnSeleccion: TButton;
    BtnIntercambio: TButton;
    BtnBurbuja: TButton;
    BtnQuickSort: TButton;
    BtnEliminarRep: TButton;
    BtnOrdenarFrec: TButton;
    BtnComoString: TButton;
    EdtPos: TEdit;
    EdtNumero: TEdit;
    LblPOS: TLabel;
    LblNumero: TLabel;
    MemoResultado: TMemo;
    VECTORES: TLabel;
    SGVector: TStringGrid;
    procedure BtnAdicionarClick(Sender: TObject);
    procedure BtnBurbujaClick(Sender: TObject);
    procedure BtnBusquedaBinClick(Sender: TObject);
    procedure BtnBusquedaSecClick(Sender: TObject);
    procedure BtnCantidadClick(Sender: TObject);
    procedure BtnCargarClick(Sender: TObject);
    procedure BtnComoStringClick(Sender: TObject);
    procedure BtnEliminarRepClick(Sender: TObject);
    procedure BtnInsercionClick(Sender: TObject);
    procedure BtnInsertarClick(Sender: TObject);
    procedure BtnIntercambioClick(Sender: TObject);
    procedure BtnInvertirClick(Sender: TObject);
    procedure BtnMostrarClick(Sender: TObject);
    procedure BtnObtenerClick(Sender: TObject);
    procedure BtnOrdenarFrecClick(Sender: TObject);
    procedure BtnQuickSortClick(Sender: TObject);
    procedure BtnRotarClick(Sender: TObject);
    procedure BtnSeleccionClick(Sender: TObject);
    procedure FormCreate(Sender: TObject);
  private

  public

  end;

var
  Numero: TNumero;
  Vector: TVector;
implementation

{$R *.lfm}

{ TNumero }

procedure TNumero.FormCreate(Sender: TObject);
begin
  Vector := TVector.Crear(5);
end;

procedure TNumero.BtnAdicionarClick(Sender: TObject);
begin
   Vector.Adicionar(StrToInt(EdtNumero.Text));
   SGVector.Cells[Vector.Cantidad - 1, 0] := EdtNumero.Text;
   EdtNumero.Clear;
end;

procedure TNumero.BtnBurbujaClick(Sender: TObject);
var
  i: Integer;
begin
  Vector.OrdenarBurbuja;
  for i := 0 to Vector.Cantidad - 1 do
    SGVector.Cells[i, 0] := IntToStr(Vector.Obtener(i));
  MemoResultado.Text := Vector.Mostrar;
end;

procedure TNumero.BtnBusquedaBinClick(Sender: TObject);
var
  x, pos: Integer;
begin
  x := StrToInt(EdtNumero.Text);
  pos := Vector.BusquedaBinaria(x);
  if pos >= 0 then
    MemoResultado.Text := 'Encontrado en la posición: ' + IntToStr(pos)
  else
    MemoResultado.Text := 'No se encontró el elemento';
end;

procedure TNumero.BtnBusquedaSecClick(Sender: TObject);
var
  x, pos: Integer;
begin
  x := StrToInt(EdtNumero.Text);
  pos := Vector.BusquedaSecuencial(x);
  if pos >= 0 then
    MemoResultado.Text := 'Encontrado en la posición: ' + IntToStr(pos)
  else
    MemoResultado.Text := 'No se encontró el elemento';
end;

procedure TNumero.BtnCantidadClick(Sender: TObject);
begin
  MemoResultado.Text := 'Cantidad: ' + IntToStr(Vector.Cantidad);
end;

procedure TNumero.BtnCargarClick(Sender: TObject);
var
  i: Integer;
begin
  Vector.Cargar;
  SGVector.ColCount := Vector.Cantidad;
  for i := 0 to Vector.Cantidad - 1 do
    SGVector.Cells[i, 0] := IntToStr(Vector.Obtener(i));
  MemoResultado.Text := Vector.Mostrar;
end;

procedure TNumero.BtnComoStringClick(Sender: TObject);
begin
  MemoResultado.Text := Vector.ComoString;
end;

procedure TNumero.BtnEliminarRepClick(Sender: TObject);
var
  i: Integer;
begin
  Vector.EliminarRep;
  SGVector.ColCount := Vector.Cantidad;
  for i := 0 to Vector.Cantidad - 1 do
    SGVector.Cells[i, 0] := IntToStr(Vector.Obtener(i));
  MemoResultado.Text := Vector.Mostrar;
end;

procedure TNumero.BtnInsercionClick(Sender: TObject);
var
  i: Integer;
begin
  Vector.OrdenarInsercion;
  for i := 0 to Vector.Cantidad - 1 do
    SGVector.Cells[i, 0] := IntToStr(Vector.Obtener(i));
  MemoResultado.Text := Vector.Mostrar;
end;

procedure TNumero.BtnInsertarClick(Sender: TObject);
var
  x, pos, i: Integer;
begin
  x := StrToInt(EdtNumero.Text);
  pos := StrToInt(EdtPos.Text);
  Vector.Insertar(pos, x);
  SGVector.ColCount := Vector.Cantidad;
  for i := 0 to Vector.Cantidad - 1 do
    SGVector.Cells[i, 0] := IntToStr(Vector.Obtener(i));
  MemoResultado.Text := Vector.Mostrar;
end;

procedure TNumero.BtnIntercambioClick(Sender: TObject);
var
  i: Integer;
begin
  Vector.OrdenarIntercambio;
  for i := 0 to Vector.Cantidad - 1 do
    SGVector.Cells[i, 0] := IntToStr(Vector.Obtener(i));
  MemoResultado.Text := Vector.Mostrar;
end;

procedure TNumero.BtnInvertirClick(Sender: TObject);
var
  i: Integer;
begin
  Vector.Invertir;
  for i := 0 to Vector.Cantidad - 1 do
    SGVector.Cells[i, 0] := IntToStr(Vector.Obtener(i));
  MemoResultado.Text := Vector.Mostrar;
end;

procedure TNumero.BtnMostrarClick(Sender: TObject);
begin
  MemoResultado.Text := Vector.Mostrar;
end;

procedure TNumero.BtnObtenerClick(Sender: TObject);
var
  pos: Integer;
begin
  pos := StrToInt(EdtPos.Text);
  MemoResultado.Text :=
    'Elemento: ' + IntToStr(Vector.Obtener(pos));
end;

procedure TNumero.BtnOrdenarFrecClick(Sender: TObject);
var
  i: Integer;
begin
  Vector.OrdenarFrec;
  SGVector.ColCount := Vector.Cantidad;
  for i := 0 to Vector.Cantidad - 1 do
    SGVector.Cells[i, 0] := IntToStr(Vector.Obtener(i));
  MemoResultado.Text := Vector.Mostrar;
end;

procedure TNumero.BtnQuickSortClick(Sender: TObject);
var
  i: Integer;
begin
  Vector.QuickSort;
  for i := 0 to Vector.Cantidad - 1 do
    SGVector.Cells[i, 0] := IntToStr(Vector.Obtener(i));
  MemoResultado.Text := Vector.Mostrar;
end;

procedure TNumero.BtnRotarClick(Sender: TObject);
var
  i: Integer;
begin
  Vector.Rotar;
  for i := 0 to Vector.Cantidad - 1 do
    SGVector.Cells[i, 0] := IntToStr(Vector.Obtener(i));
  MemoResultado.Text := Vector.Mostrar;
end;

procedure TNumero.BtnSeleccionClick(Sender: TObject);
var
  i: Integer;
begin
  Vector.OrdenarSeleccion;
  for i := 0 to Vector.Cantidad - 1 do
    SGVector.Cells[i, 0] := IntToStr(Vector.Obtener(i));
  MemoResultado.Text := Vector.Mostrar;
end;

end.

